insert into perfil(nome, pis, cpf, cep, rua, numero, complemento, cidade_id) VALUES ('joel', '00628123337', '04171650305', '60730235', 'R comendador garcia', '1746', 'A', 3500);
insert into usuario (email, senha, cargo_id, perfil_id) values ('joel.victor.castro04@aluno.ifce.edu.br', 'sha256$l2ygbSdF$2d03f994b4d99fdf6ca30832852826564189f3438a9f6abc7249bc74c08b7843', 2, 1);

