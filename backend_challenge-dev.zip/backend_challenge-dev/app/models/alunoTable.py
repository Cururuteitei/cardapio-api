from app import db

class Aluno(db.Model):
    matricula = db.Column(db.String(30), primary_key=True)
    nome = db.Column(db.String(100), nullable = False)
    email= db.Column(db.String(100), nullable=False)
    alunorefeicoes = db.relationship('AlunoRefeicoes', backref='aluno', lazy=True)


    def __init__(self, nome, email, matricula):
        self.nome=nome 
        self.email = email
        self.matricula = matricula

    def __repr__(self):
        str= "<Aluno{} {} {}.".format(self.matricula, self.nome, self.email)  
        return str

    def to_dict(self):
        return{
            "matricula": self.matricula,
            "nome": self.nome,
            'email': self.email
        }