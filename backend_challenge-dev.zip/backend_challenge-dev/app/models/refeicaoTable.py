from app import db

class Refeicao(db.Model):
	__tablename__ = "refeicao"

	id = db.Column(db.BigInteger, primary_key = True)
	nome = db.Column(db.String(255), nullable=False)

	tipo_refeicao_id = db.Column(db.Integer, db.ForeignKey('tipo_refeicao.id'), nullable=False)
	cardapio_id = db.Column(db.Integer, db.ForeignKey('cardapio.id'), nullable=False)
	prato_id = db.Column(db.Integer, db.ForeignKey('prato.id'), nullable=False)
	alunorefeicoes = db.relationship('AlunoRefeicoes', backref='refeicao', lazy=True)
	avalicoes = db.relationship('Avaliacoes', backref='refeicao', lazy=True)

	#--------------------------------------------------------------------------------------------------#
	
	def __init__(self, nome: str, prato_id: int, cardapio_id:int, tipo_refeicao_id:int):
		self.nome = nome
		self.prato_id = prato_id
		self.cardapio_id = cardapio_id
		self.tipo_refeicao_id = tipo_refeicao_id

	#--------------------------------------------------------------------------------------------------#
		
	def __repr__(self):
		return "<Refeicao %r %r %r %r %r>" %(self.id, self.nome, self.prato_id, self.cardapio_id, self.tipo_refeicao_id)
