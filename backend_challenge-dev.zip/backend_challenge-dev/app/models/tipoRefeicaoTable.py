from app import db

class TipoRefeicao(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable = False)
    refeicoes = db.relationship('Refeicoes', backref='tipo_refeicao', lazy=True)
    def __init__(self, nome):
        self.nome = nome 


    def __repr__(self):
        str= "<TipoRefeicao{} {} {}.".format(self.id, self.nome)  
        return str

    def to_dict(self):
        return{
            "id": self.id,
            "nome": self.nome,

        }