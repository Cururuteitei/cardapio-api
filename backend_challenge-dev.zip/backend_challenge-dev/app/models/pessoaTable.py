from app import db

class Pessoa(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable = False)
    email = db.Column(db.String(100), nullable = False)

    def __init__(self, nome, email):
        self.nome=nome 
        self.email = email

    def __repr__(self):
        str= "<Pessoa{} {} {}.".format(self.id, self.nome, self.email)  
        return str

    def to_dict(self):
        return{
            "id": self.id,
            "nome": self.nome,
            'email': self.email
        }