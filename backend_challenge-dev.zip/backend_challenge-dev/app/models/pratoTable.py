from app import db

class Prato(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable = False)
    refeicoes = db.relationship('Refeicoes', backref='prato', lazy=True)

    def __init__(self, nome):
        self.nome=nome 
        

    def __repr__(self):
        str= "<Prato{} {} {}.".format(self.id, self.nome)  
        return str

    def to_dict(self):
        return{
            "id": self.id,
            "nome": self.nome
        }