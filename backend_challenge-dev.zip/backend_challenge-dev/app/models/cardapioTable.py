from app import db

class Cardapio(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    nome = db.Column(db.String(100), nullable = False)
    data = db.Column(db.Date, nullable=False)
    refeicoes = db.relationship('Refeicoes', backref='cardapio', lazy=True)

    def __init__(self, nome, data):
        self.nome=nome 
        self.data = data

    def __repr__(self):
        str= "<Cardapio{} {} {}.".format(self.id, self.nome, self.data)  
        return str

    def to_dict(self):
        return{
            "id": self.id,
            "nome": self.nome,
            'data': self.data
        }