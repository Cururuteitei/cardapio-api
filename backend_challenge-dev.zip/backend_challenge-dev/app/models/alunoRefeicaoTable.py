from app import db

class AlunoRefeicao(db.Model):
    refeicao_id = db.Column(db.BigInteger, db.ForeignKey("refeicao.id"), nullable=True, primary_key=True)
    aluno_id = db.Column(db.String(30), db.ForeignKey("aluno.matricula"), nullable=True, primary_key=True)
    confirmado= db.Column(db.Boolean, nullable = False)
    
    
    def __init__(self, confirmado, aluno_id:str, refeicao_id:int):
            self.confirmado = confirmado
            self.aluno_id = aluno_id
            self.refeicao_id = refeicao_id

        #--------------------------------------------------------------------------------------------------#
    def __repr__(self):
            return "<Refeicao %r %r %r >" %(self.confirmado, self.aluno_id, self.refeicao_id)

