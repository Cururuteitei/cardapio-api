from app import db

class Avalicoes(db.Model):
    id = db.Column(db.BigInteger, primary_key=True)
    refeicao_id = db.Column(db.BigInteger, db.ForeignKey("refeicao.id"), nullable=True, primary_key=True)
    comentario = db.Column(db.Text, nullable = False)
    nota = db.Column(db.Integer,nullable=False)

    def __init__(self, id, nota, comentario):
        self.id=id 
        self.comentario = comentario
        self.nota = nota

    def __repr__(self):
        str= "<Avaliacao{} {} {}.".format(self.id, self.comentario, self.nota)  
        return str

    def to_dict(self):
        return{
            "matricula": self.id,
            "nome": self.comentario,
            'email': self.nota
        }