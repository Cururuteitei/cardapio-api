
SCENARIO_USER = {
    "cargo_id": 2,
    "email": "teste@gmail.com",
    "senha": "123456",
    "nome": "Teste",
    "pis": "818.74405.80-3",
    "cpf": "041.825.540-78",
    "cep": "60730-245",
    "rua": "R Einstein",
    "numero": "22",
    "complemento": "A",
    "cidade_id": 3500
}